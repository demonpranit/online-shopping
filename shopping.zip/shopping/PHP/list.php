<?php

include ('header.php')
?>

<?php
$db = new DBController();
$product = new product($db);
$product_shuffle = $product->getData();
$brand = array_map(function ($pro){ return $pro['item_brand']; }, $product_shuffle);
$unique = array_unique($brand);
sort($unique);
shuffle($product_shuffle);

if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if (isset($_POST['special_price_submit'])) {
        //call method add to cart
        $Cart = new Cart($db);
        $Cart->addToCart($_POST['user_id'], $_POST['item_id']);
    }
}

$in_cart = $Cart->getCartid($product->getData('cart'))
?>
<?php
$item_id = $_GET['item_id']??1;
$db = new DBController();
$product = new product($db);
foreach ($product->getData() as $item):
    if ($item['item_id'] == $item_id):
        ?>



        <link rel="stylesheet" href="list.css" type="text/css"/>


    <section id="special-price">
        <div class="container" style="max-width: 1140px">
            <h4 class="font-rubik font-size-20">All Product</h4>
            <div id="filters" class="button-group text-right font-balon font-size-16">
            <button class="btn is-checked"data-filter="*">All Brand</button>
            <?php
                array_map(function($brand){
                    printf('<button class="btn"data-filter=".%s">%s</button>',$brand,$brand);
                }, $unique);
            ?>

        </div>
              <div class="grid">
            <?php array_map(function($item) use($in_cart){?>
    <div class="col-xs-21 " >

        <!-- First product box start here-->
        <div class="prod-info-main prod-wrap clearfix">

            <div class="row">

                <div class="col-md-3 col-xs-10">

                    <div class="product-image">
                        <a href="<?php printf('%s?item_id=%s','product.php', $item['item_id']) ?>"><img src="<?php echo $item['item_image'] ?? "./assets/products/13.png";?>" alt="product" class="img-fluid"></a>
                    </div>

                </div>

                <div class="col-md-7 col-sm-12 col-xs-12">

                    <div class="product-deatil">

                            <h6><?php echo $item["item_name"]?? "Unknown";?></h6>
                        <div class="col-md-12">
                            <div class="rating">Rating:
                                <label for="stars-rating-5"><i class="fa fa-star text-danger"></i></label>
                                <label for="stars-rating-4"><i class="fa fa-star text-danger"></i></label>
                                <label for="stars-rating-3"><i class="fa fa-star text-danger"></i></label>
                                <label for="stars-rating-2"><i class="fa fa-star text-warning"></i></label>
                                <label for="stars-rating-1"><i class="fa fa-star text-warning"></i></label>
                            </div>
                        </div>


                        <div class="price-container">
                                <span>$<?php echo $item['item_price']?? 0?></span>
                        </div>
                        <span class="tag1"></span>
                    </div>
                    <div class="description">
                        <p> Snapdragon 695 5G Mobile Platform allows you to level up your performance with efficient</p>
                    </div>

                    <div class="product-info smart-form">

                        <div class="row">

                            <div class="col-md-12">

                               <form method="post">
                                <input type="hidden" name="item_id" value="<?php echo $item['item_id']??'1';?>">
                                <input type="hidden" name="user_id" value="<?php echo 1;?>">
                                <?php
                                if (in_array($item['item_id'],$in_cart??[])){
                                    echo '<button type="submit" disabled name="top_sale_submit" class="btn btn-success font-size-12">In the Cart</button>';
                                }else{
                                    echo '<button type="submit" name="top_sale_submit" class="btn btn-warning font-size-12">Add to Cart</button>';
                                }
                                ?>

                            </form>
                            </div>


                        </div>

                    </div>
                    <hr>

                </div>
                <?php },$product_shuffle)?>


            </div>
        </div>

        <!-- end product -->

    </div>
</div>



        </div
    </section>

    <?php
    endif;
endforeach;;

?>
