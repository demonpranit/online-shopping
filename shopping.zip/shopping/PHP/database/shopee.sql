-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2020 at 11:01 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopee`
--

-- --------------------------------------------------------
--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
    `categorie_id` int(12) NOT NULL,
    `categorie_name` varchar(255) NOT NULL,
    `categorie_desc` text NOT NULL,
    `categorie_createdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categorie_id`, `categorie_name`, `categorie_desc`, `categorie_createdate`) VALUES
    (1, 'Apple', 'The iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera and cellular phone into one device with a touchscreen interface.', '2022-03-17 18:16:28'),
    (2, 'Redmi', 'Xiaomi is a privately owned company that designs, develops, and sells smartphones, an Android-based OS, and other consumer electronics.', '2022-03-17 18:17:14'),
    (3, 'Realme', ' Realme is an offshoot of the Chinese brand Oppo, and aims to provide smartphones under Rs. 20,000 for the "young people around the world.', '2022-03-17 18:17:43'),
    (4, 'Asus', 'ASUS smartphones including ZenFone and ROG Phone series offer the latest high-end components and software to have the best user experiences.', '2022-03-17 18:19:10'),
    (5, 'Samsung', 'Samsung Galaxy is a series of computing and mobile computing devices that are designed, manufactured and marketed by Samsung Electronics.', '2022-03-17 21:58:58'),
    (6, 'Oppo', 'OPPO Electronics Corp. is an electronics manufacturer based in Guangdong, China. Known for its smartphones, the company also makes MP3 ...', '2022-03-18 07:55:28'),
    (7, 'Vivo', 'Vivo Electronics Corp. is a phone brand based in Dongguan, Guangdong, China. It was founded in 2009. The company is another Chinese smartphone ...', '2022-03-18 08:06:30'),
    (8, 'Nokia', 'Nokia 3.2 features an impressive 6.26” HD+ screen, plus facial recognition technology, 13 MP camera and long battery life. Discover more with Nokia.', '2022-03-18 08:13:47');

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `product_Id` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp()
)  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
    ADD PRIMARY KEY (`categorie_id`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorie_name` (`categorie_name`,`categorie_desc`);

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
    `id` int(21) NOT NULL,
    `orderId` int(21) NOT NULL,
    `item_id` int(21) NOT NULL,
    `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
    `contactId` int(21) NOT NULL,
    `userId` int(21) NOT NULL,
    `email` varchar(35) NOT NULL,
    `phoneNo` bigint(21) NOT NULL,
    `orderId` int(21) NOT NULL DEFAULT 0 COMMENT 'If problem is not related to the order then order id = 0',
    `message` text NOT NULL,
    `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
--
-- Table structure for table `contactreply`
--

CREATE TABLE `contactreply` (
    `id` int(21) NOT NULL,
    `contactId` int(21) NOT NULL,
    `userId` int(23) NOT NULL,
    `message` text NOT NULL,
    `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------


--
-- Table structure for table `deliverydetails`
--

CREATE TABLE `deliverydetails` (
    `id` int(21) NOT NULL,
    `orderId` int(21) NOT NULL,
    `deliveryBoyName` varchar(35) NOT NULL,
    `deliveryBoyPhoneNo` bigint(25) NOT NULL,
    `deliveryTime` int(200) NOT NULL COMMENT 'Time in minutes',
    `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------


--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
    `id` int(21) NOT NULL,
    `orderId` int(21) NOT NULL,
    `item_id` int(21) NOT NULL,
    `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
    `orderId` int(21) NOT NULL,
    `userId` int(21) NOT NULL,
    `address` varchar(255) NOT NULL,
    `zipCode` int(21) NOT NULL,
    `phoneNo` bigint(21) NOT NULL,
    `amount` int(200) NOT NULL,
    `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=cash on delivery, \r\n1=online ',
    `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0' COMMENT '0=Order Placed.\r\n1=Order Confirmed.\r\n2=Preparing your Order.\r\n3=Your order is on the way!\r\n4=Order Delivered.\r\n5=Order Denied.\r\n6=Order Cancelled.',
    `orderDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `item_id` int(11) NOT NULL,
  `item_brand` varchar(200) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_desc` text NOT NULL,
  `item_image` varchar(255) NOT NULL,
  'item_video' varchar(255) NOT NULL,
  `item_register` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`item_id`, `item_brand`, `item_name`, `item_price`, `item_desc`, `item_image`,'item_video', `item_register`) VALUES
    (1, 'Samsung', 'Samsung Galaxy 10', 15200.00, 'The Galaxy S10 packs in a 3400mAh battery and manages to deliver over one day of battery life', '/assets/products/1.png', './assets/vid/1.mp4', '2022-03-28 11:08:57'), -- NOW()
    (2, 'Redmi', 'Redmi Note 7', 12200.00, 'Xiaomi Redmi Note 7 ; Performance. Octa core (2.2 GHz, Quad Core + 1.8 GHz, Quad core) Snapdragon 660 3 GB RAM ; Display. 6.3 inches (16 cm) 409 PPI, IPS LCD.', './assets/products/2.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (3, 'Redmi', 'Redmi Note 6', 12200.00, 'Xiaomi Redmi Note 6 Pro ; Display 6.26-inch (1080x2280) ; Processor Qualcomm Snapdragon 636 ; Front Camera 20MP + 2MP ; Rear Camera 12MP + 5MP ; RAM 4GB.', './assets/products/3.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (4, 'Redmi', 'Redmi Note 5', 12200.00, 'Xiaomi Redmi Note 4 ; Display 5.50-inch (1080x1920) ; Processor Qualcomm Snapdragon 625 ; Front Camera 5MP ; Rear Camera 13MP ; RAM 2GB.', './assets/products/4.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (5, 'Redmi', 'Redmi Note 4', 12200.00, 'Xiaomi Redmi Note 6 Pro ; Display 6.26-inch (1080x2280) ; Processor Qualcomm Snapdragon 636 ; Front Camera 20MP + 2MP ; Rear Camera 12MP + 5MP ; RAM 4GB.', './assets/products/5.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (6, 'Redmi', 'Redmi Note 8', 12200.00, 'Redmi Note 8 (4GB RAM, 64GB) ; Display 6.30-inch (1080x2280) ; Processor Qualcomm Snapdragon 665 ; Front Camera 13MP ; Rear Camera 48MP + 8MP + 2MP + 2MP ; RAM 4GB.', './assets/products/6.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (7, 'Redmi', 'Redmi Note 9', 12200.00, 'Redmi Note 9 ; Front Camera 13MP ; Rear Camera 48MP + 8MP + 2MP + 2MP ; RAM 4GB ; Storage 64GB ; Battery Capacity 5020mAh.', './assets/products/8.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (8, 'Redmi', 'Redmi Note', 12200.00, 'Redmi Note 9 ; Front Camera 13MP ; Rear Camera 48MP + 8MP + 2MP + 2MP ; RAM 4GB ; Storage 64GB ; Battery Capacity 5020mAh.', './assets/products/10.png', './assets/vid/2.mp4', '2022-03-28 11:08:57'),
    (9, 'Samsung', 'Samsung Galaxy S6', 15200.00, 'Samsung Galaxy S6 32GB Specifications ; Samsung Exynos 7 Octa 7420 · Mali-T760 MP8 · Octa core (2.1 GHz, Quad core, ARM Cortex A57 + 1.5 GHz, Quad core, Cortex A53)', './assets/products/11.png', './assets/vid/1.mp4', '2022-03-28 11:08:57'),
    (10, 'Samsung', 'Samsung Galaxy S7', 15200.00, 'Samsung Galaxy S7 Edge Brief Description. Samsung Galaxy S7 Edge was launched in May 2017 & runs on Android 6.0 OS. The Smartphone is available in more than ...', './assets/products/12.png', './assets/vid/1.mp4', '2022-03-28 11:08:57'),
    (11, 'Apple', 'Apple iPhone 5', 15200.00, 'Apple iPhone 5 ; CPU, Dual-core 1.3 GHz Swift (ARM v7-based) ; GPU, PowerVR SGX 543MP3 (triple-core graphics) ; Memory, Card slot ; Internal, 16GB 1GB RAM, 32GB 1GB','./assets/products/13.png', './assets/vid/3.mp4', '2022-03-28 11:08:57'),
    (12, 'Apple', 'Apple iPhone 6', 15200.00, 'Apple iPhone 5 ; CPU, Dual-core 1.3 GHz Swift (ARM v7-based) ; GPU, PowerVR SGX 543MP3 (triple-core graphics) ; Memory, Card slot ; Internal, 16GB 1GB RAM, 32GB 1GB', './assets/products/14.png', './assets/vid/3.mp4', '2022-03-28 11:08:57'),
    (13, 'Apple', 'Apple iPhone x', 15200.00, 'Description Apple iPhone X is the latest iPhone to mark Apple''s 10th anniversary. It is powered by Apple''s latest A11 Bionic chip.', './assets/products/15.png', './assets/vid/3.mp4', '2022-03-28 11:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--
CREATE TABLE 'video' (
    `item_id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `item_name` varchar(255) NOT NULL,
    'item_video' varchar(255) NOT NULL,
    'location' varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ---------------------------------------
--
-- Table structure for table `sitedetail`
--

CREATE TABLE `sitedetail` (
    `tempId` int(11) NOT NULL,
    `systemName` varchar(21) NOT NULL,
    `email` varchar(35) NOT NULL,
    `contact1` bigint(21) NOT NULL,
    `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
    `address` text NOT NULL,
    `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
    (1, 'Mobile Domain', 'pratikjadhav2001@gmail.com', 2515469442, 6304468851, 'Tukaram Nagar.<br> Dombivli (E)', '2022-03-23 19:56:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
    `id` int(21) NOT NULL,
    `username` varchar(21) NOT NULL,
    `firstName` varchar(21) NOT NULL,
    `lastName` varchar(21) NOT NULL,
    `email` varchar(35) NOT NULL,
    `phone` bigint(20) NOT NULL,
    `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user\r\n1=admin',
    `password` varchar(255) NOT NULL,
    `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `joinDate`) VALUES
    (1, 'demon', 'demon', 'demon', 'demon@gmail.com', 1111111111, '1', '$2y$10$ilYX4GAUakMqfKwBpFKjcOCqvz3w5UrGcnaBXvxRgyMhcvAvwN.TC', '2022-04-11 11:40:58');

-- --------------------------------------------------------
--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
    ADD PRIMARY KEY (`categorie_id`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorie_name` (`categorie_name`,`categorie_desc`);


--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
    ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `contactreply`
--
ALTER TABLE `contactreply`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliverydetails`
--
ALTER TABLE `deliverydetails`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
    ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `pizza`
--
ALTER TABLE `product`
    ADD PRIMARY KEY (`item_id`);
ALTER TABLE `product` ADD FULLTEXT KEY `item_name` (`item_name`,`item_desc`);

--
-- Indexes for table `sitedetail`
--
ALTER TABLE `sitedetail`
    ADD PRIMARY KEY (`tempId`);

-- Indexes for table `users`
--
ALTER TABLE `users`
    ADD PRIMARY KEY (`id`) USING BTREE,
    ADD UNIQUE KEY `username` (`username`);

-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
    MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
    MODIFY `categorie_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
    ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `contactreply`
--
ALTER TABLE `contactreply`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliverydetails`
--
ALTER TABLE `deliverydetails`
    ADD PRIMARY KEY (`id`),
    ADD UNIQUE KEY `orderId` (`orderId`);
--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
    ADD PRIMARY KEY (`orderId`);


--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for table `viewcart`
--
ALTER TABLE `cart`
    MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
