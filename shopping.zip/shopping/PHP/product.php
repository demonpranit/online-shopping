<?php
ob_start();
//include header.php file
include ('header.php');
?>

<?php

/* include products*/
include ('Template/_products.php');

/* End include products*/

/* include top sale*/
include ('Template/_top-sale.php');

/* End include top sale*/
?>


<?php
//include footer.php file
include ('footer.php');
?>
