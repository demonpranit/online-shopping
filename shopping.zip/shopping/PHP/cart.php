<?php


ob_start();

//include header.php file
include ('header.php');
?>

<?php
$db = new DBController();
$product = new Product($db);

/* include cart template*/
count($product->getData('cart')) ? include ('Template/_cart-template.php'):include ('Template/notFound/_cart_notFound.php');



/* End include cart template*/


/* include whishlist template*/
count($product->getData('wishlist')) ? include ('Template/_wishlist_template.php'):include ('Template/notFound/_wishlist_notfound.php');


/* include New Phone*/
include ('Template/_new-phone.php');

/* End include New Phone*/
?>


<?php

//include footer.php file
include ('footer.php');
?>

