<!--Banner adds-->
<section id="banner_adds">
    <div class="container py-5 text-center">
        <img src="./assets/banner3.jpg" alt="banner1" class="img-fluid">
        <img src="./assets/banner4.jpg" alt="banner1" class="img-fluid">

    </div>
</section>
<!--Banner adds ends-->
