<!--Shopping cart section-->


<section id="cart" class="py-3 mb-5">
    <div class="container-fluid w-75">
        <h5 class="font-baloo font-size-20">Shopping Cart</h5>


        <div class="row">
            <div class="col-sm-9">
               <!--Empty cart-->
                <div class="row border-top py-3 mt-3">
                    <div class="col-sm-12 text-center py-1">
                        <img src="./assets/blog/empty_cart.png" alt="Empty cart" class="img-fluid" style="height: 200px">
                        <p class="font-size-16 text-black-50">Empty cart</p>
                    </div>
                </dv>


                <!--Empty cart-->

            </div>
            <!--subtotal section-->
            <!--subtotal section-->


        </div>
        <!--end shopping cart items-->

    </div>
</section>

<!--End Shopping cart section-->
